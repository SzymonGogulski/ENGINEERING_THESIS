
from audio_preprocess import split_noise_to_samples, mix_key_word_and_noise_samples

print('some')
# Run these lines to prepare the data.
# split_noise_to_samples('noise', 'noise_samples', 'mp3', 'wav', 16000, 1)
# mix_key_word_and_noise_samples(
#     'key_words', 'noise_samples', 'key_words_with_noise', 'wav', 'wav')

# Run t-SNE visualization.
